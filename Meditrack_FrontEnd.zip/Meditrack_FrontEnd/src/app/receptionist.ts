export class Receptionist {
         receptionistId:number;
		 receptionistName:string;
		 emailAdress:string;
		 password:string;
		 gender:string;
		 contactNo:string;
		 doctorId:number;
}

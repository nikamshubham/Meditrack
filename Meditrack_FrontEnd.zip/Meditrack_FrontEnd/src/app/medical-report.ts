export class MedicalReport {
	 reportId:number;
	 doctorName:string;
	 receptionistName:string;
	 disese:string;
	 tests:string;
	 nextAppoitnmentDt:string;
	 clinicName:string;
	 pid:number;
}

import { MedicalReport } from './medical-report';

describe('MedicalReport', () => {
  it('should create an instance', () => {
    expect(new MedicalReport()).toBeTruthy();
  });
});

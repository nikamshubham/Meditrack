export class Patient {
    pid2:number;
    firtName: string;
    lastName: string;
    gender:string;
    emailId: string ;
    password:string ;
	age:number;
    contactNo:string ;
    aadharNo:string ;
    address:string ;
}

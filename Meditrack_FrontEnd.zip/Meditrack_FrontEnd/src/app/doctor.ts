export class Doctor {
    doctorId:number;
     doctorName:string;
	 emailId:string;
	 password:string;
	 education:string;
	 specialization:string;
	 workingDays:string;
	 gender:string;
}

export class Admin {
    adminName: string;
    emailId: number;
    password: string;
}

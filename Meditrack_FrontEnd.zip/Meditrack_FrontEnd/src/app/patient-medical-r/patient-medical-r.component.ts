import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-medical-r',
  templateUrl: './patient-medical-r.component.html',
  styleUrls: ['./patient-medical-r.component.css']
})
export class PatientMedicalRComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

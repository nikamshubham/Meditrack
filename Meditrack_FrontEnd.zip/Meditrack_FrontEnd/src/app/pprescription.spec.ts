import { PPrescription } from './pprescription';

describe('PPrescription', () => {
  it('should create an instance', () => {
    expect(new PPrescription()).toBeTruthy();
  });
});

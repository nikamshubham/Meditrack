import { AppointmentRecord } from './appointment-record';

describe('AppointmentRecord', () => {
  it('should create an instance', () => {
    expect(new AppointmentRecord()).toBeTruthy();
  });
});

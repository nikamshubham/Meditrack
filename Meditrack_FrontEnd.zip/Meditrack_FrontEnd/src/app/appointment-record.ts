export class AppointmentRecord {
     recordId:number;
	 receptionistId:number;
	 patientId:number;	
	 patientName:string;
	 appointmentDate:string;
	 appointmentStatus:string;
	doctorId:number;
     
}

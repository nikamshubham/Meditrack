export class PatientAuthentication {
     pAId:number;
	 emailId:string;
	 key:string;

}

import { PatientAuthentication } from './patient-authentication';

describe('PatientAuthentication', () => {
  it('should create an instance', () => {
    expect(new PatientAuthentication()).toBeTruthy();
  });
});

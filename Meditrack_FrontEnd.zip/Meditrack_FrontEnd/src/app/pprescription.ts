export class PPrescription {
     medicineId:number;
	 medicineName:string;
	 dailyDosage:string;
	 uptoDate:string;
	 fromDate:string;
	 status1:string;
	 pid1:number;
}

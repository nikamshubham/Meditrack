import { Receptionist } from './receptionist';

describe('Receptionist', () => {
  it('should create an instance', () => {
    expect(new Receptionist()).toBeTruthy();
  });
});
